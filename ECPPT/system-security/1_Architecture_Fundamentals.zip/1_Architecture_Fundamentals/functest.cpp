// eLearnSecurity

void functest(int a, int b, int c) {
 int test1 = 55;
 int test2 = 56; 
} 
int main() {
 int x = 11;
 int z = 12; 
 int y = 13; 
 functest(30,31,32);
 return 0; 
}

