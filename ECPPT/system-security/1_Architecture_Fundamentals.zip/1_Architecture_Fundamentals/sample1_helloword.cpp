/*
eLearnSecurity
*/
#include <iostream>  //include standard Input/Output library 
#include <windows.h>

int main()  //main funtion
{
  std::cout <<"Hello Student!\n";  // standard Output stream
                                   // that print 'Hello Student'
  return 0;
}
