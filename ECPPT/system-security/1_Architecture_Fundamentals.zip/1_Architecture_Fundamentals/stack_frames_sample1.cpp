// eLearnSecurity

int b(){ //function b 
	return 0; 
} 
int a(){ // function a
	b();
	return 0; 
} 
int main (){//main function 
	a(); 
	return 0; 
}

