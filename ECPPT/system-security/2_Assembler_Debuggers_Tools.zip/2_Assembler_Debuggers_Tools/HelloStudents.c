#include <stdio.h>
int main()
{
printf("Hello students!\n");
return 0;
}
